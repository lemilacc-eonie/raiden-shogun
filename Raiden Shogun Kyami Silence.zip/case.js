/* 

#- Credits Kyami Silence
 • Contact: 6285640493829
 • YouTube: @SlncKyami
 
*/

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const ytdl = require('node-yt-dl');
const speed = require('performance-now');
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const ytSearch = require('yt-search')
const { exec, spawn, execSync } = require('child_process');
const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys');

const contacts = JSON.parse(fs.readFileSync("./database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
const list = JSON.parse(fs.readFileSync("./database/list.json"))
const { LoadDataBase } = require('./src/message');
const { TelegraPh, uploaderV2 } = require('./lib/uploader');
const { imageToWebp, videoToWebp, writeExif } = require('./lib/exif');
const { chatGpt, tiktokDl, facebookDl, instaDl, instaDownload, instaStory, allDl, Ytdl, cekKhodam } = require('./lib/screaper');
const { pinterest, pinterest2, wallpaper, wikimedia, quotesAnime, happymod, umma, ringtone, styletext, ssweb, igstalk, tts, remini, mediafire } = require('./lib/scraper');
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, toRupiah } = require('./lib/function');


module.exports = Kyami = async (Kyami, m, chatUpdate, store) => {
	try {
await LoadDataBase(Kyami, m)
const botNumber = await Kyami.decodeJid(Kyami.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = '.'
const isCmd = body.startsWith(prefix)
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const isCreator = isOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender) ? true : owners.includes(m.sender) ? true : false
const isPremium = premium.includes(m.sender)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const reply = async (teks) => {
return Kyami.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: 'https://files.catbox.moe/2cm69w.jpg', 
sourceUrl: null, 
}}}, {quoted: qkontak})
}
const qkontak = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `${namaOwner}`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6285640493829:+62 8564-0493-829\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}
//============== [ MESSAGE ] ================================================

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

if (isCmd) {
console.log(chalk.cyan.bold(`### COMMAND NOTIFICATION ###`), chalk.blue.bold(`\n💬 Command :`), chalk.white.bold(`${prefix+command}`), chalk.blue.bold(`\n👤 Sender :`), chalk.white.bold(m.isGroup ? `Group • ${m.sender.split("@")[0]}` : m.sender.split("@")[0] +`\n`))
}

//============= [ FAKEQUOTED ] ===============================================

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `Marketplace - ${namaOwner}`}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `${botname2} By ${namaOwner}`,jpegThumbnail: await reSize("./src/media/fake.jpg", 200, 200) }}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Marketplace - ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Raiden Shogun"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}

Kyami.newsletterFollow('120363366790950043@newsletter')
Kyami.newsletterFollow('120363402156788257@newsletter')
Kyami.newsletterFollow('120363415603332542@newsletter')
Kyami.newsletterFollow('120363403369857859@newsletter')
Kyami.newsletterFollow('120363315153310448@newsletter')
const qtroli = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },"message": {"orderMessage": {"orderId": "594071395007984","thumbnail": await reSize("./src/media/menu.jpg", 200, 200),"itemCount": 9999999999,"status": "INQUIRY","surface": "CATALOG","message": `Raiden Shogun`, "orderTitle": "Kyami Silence","sellerJid": "0@s.whatsapp.net","token": "AR40+xXRlWKpdJ2ILEqtgoUFd45C8rc1CMYdYG/R2KXrSg==","totalAmount1000": "500000000000000","totalCurrencyCode": "IDR"}}}

//============= [ EVENT GROUP ] ===============================================

global.reza = false

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await Kyami.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
Kyami.sendMessage(m.chat, {text: `*- [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await Kyami.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await Kyami.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await Kyami.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
Kyami.sendMessage(m.chat, {text: `*- [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await Kyami.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await Kyami.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}

Kyami.autoshalat = Kyami.autoshalat ? Kyami.autoshalat : {}
let id = m.chat 
if (id in Kyami.autoshalat) {
return false
}
let jadwalSholat = { shubuh: '04:29', terbit: '05:44', dhuha: '06:02', dzuhur: '12:02', ashar: '14:49', magrib: '17:52', isya: '19:01' }
const datek = new Date((new Date).toLocaleString("en-US", {timeZone: "Asia/Jakarta"}))
const hours = datek.getHours();
const minutes = datek.getMinutes();
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
if (timeNow === waktu && m.isGroup) {
let caption = `
*\`[!] System Notifikasi\`*

Waktu *${sholat}* telah tiba
ambilah air wudhu dan segeralah sholat 

_Pukul *${waktu}* Yogyakarta dan sekitarnya_`
Kyami.autoshalat[id] = [
await Kyami.sendMessage(m.chat, {text: caption, mentions: [], contextInfo: { isForwarded: true, forwardingScore: 9999, mentionedJid: [], forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idSaluran }}}, {quoted: qlive}),
setTimeout(async () => {
delete Kyami.autoshalat[m.chat]
}, 50000)]
}}


if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await Kyami.sendMessage(m.chat, {text: `*Kyami Silence Menyediakan 🌟*
* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

*👤 Contact Kyami Silence*
* *WhatsApp Utama :*
+6285640493829
* *WhtasApp Cadangan :*
+6285640493829
https://t.me/KyamiSilence
`}, {quoted: null})
}
}


if (m.text.toLowerCase().startsWith("list-")) {
let cc = m.text.split("-")[1]
let check = list.find(e => e.key == cc.toLowerCase())
if (check) {
await reply(check.respon)
}
}

//============= [ FUNCTION ] ======================================================

var example = (teks) => {
return `\n *Contoh Penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

function capital(string) {
return string.charAt(0).toUpperCase() + string.slice(1);
}

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/logo.jpg") }, { upload: Kyami.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*Kyami Silence* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*Kyami Silence Menyediakan 🌟*

* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.

*👤 Contact Kyami Silence*
* *WhatsApp Utama :*
+6285640493829
* *WhtasApp Cadangan :*
+6285640493829
https://t.me/KyamiSilence
`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1GB : Rp1000

* Ram 2 GB : Rp2000

* Ram 3 GB : Rp3000

* Ram 4 GB : Rp4000

* Ram 5 GB : Rp5000

* Ram 6 GB : Rp6000

* Ram 7 GB : Rp7000

* Ram 8 GB : Rp8000

* Ram 9 GB : Rp9000

* Ram Unlimited : Rp10.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Jasa Suntik Sosmed 🌟*

*- Layanan Instagram :*
- 500 Followers : Rp8000
- 1000 Like : Rp4000
- 1000 Views : Rp4000

*- Layanan Tiktok :*
* 500 Followers : Rp5000
* 1000 Like : Rp5000
* 1000 Share : Rp5000
* 10k Views : Rp3000

*- Layanan Telegram :*
* 500 Member CH : Rp8000

*- Layanan Whats'App :*
* 100 Member CH : Rp12.000

*Syarat & Ketentuan :*
* _Proses tidak memerlukan email/password akun, hanya memakai username/link tautan_
* _Selama proses akun jangan di private/dibatasi_
* _Masing masing layanan mempunyai garansi & non garansi_
* _Proses maksimal 1 x 24jam, Order wajib sabar!_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qlocJpm})
await Kyami.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
}

//============= [ COMMANDS ] ====================================================

switch (command) {
case "kyami": case "allmenu": case "menu": {
let teksnya = `
╭———⪼ *⌜ BOT INFORMATION ⌟*
│• *Bot name* : ${botname}
│• *Mode :* ${Kyami.public ? "Public": "Self"}
│• *Creator :* @${global.owner}
│• *Runtime Bot :* ${runtime(process.uptime())}
│• *Uptime Vps :* ${runtime(os.uptime())}
│• *Library* : @whiskeysockets/baileys
│• *Speed* : ${runtime(os.uptime())}
╰——⪼

┏─❖ *OTHER MENU* ❖
┃𖠇 *.ᴀɪ*
┃𖠇 *.ɢᴘᴛ*
┃𖠇 *.ᴄᴇᴋɪᴅᴄʜ*
┃𖠇 *.ᴛᴏᴜʀʟ*
┃𖠇 *.ᴛᴏᴜʀʟ2*
┃𖠇 *.ᴛᴏʜᴅ*
┃𖠇 *.ᴛʀᴀɴsʟᴀᴛᴇ*
┃𖠇 *.ǫᴄ*
┃𖠇 *.sᴛɪᴄᴋᴇʀᴡᴍ*
┃𖠇 *.sᴛɪᴄᴋᴇʀ*
┃𖠇 *.sʜᴏʀᴛʟɪɴᴋ*
┃𖠇 *.ʏᴛs*
┃𖠇 *.ᴘʟᴀʏ*
┃𖠇 *.ᴘɪɴᴛᴇʀᴇsᴛ*
┃𖠇 *.ʙʀᴀᴛ*
┃𖠇 *.ʀᴠᴏ*
┗────────────❖
┏─❖ *STORE MENU* ❖
┃𖠇 *.ᴀᴅᴅʟɪsᴛ*
┃𖠇 *.ɢᴇᴛʟɪsᴛ*
┃𖠇 *.ᴅᴇʟʟɪsᴛ*
┃𖠇 *.ᴅᴏɴᴇ*
┃𖠇 *.ᴘʀᴏsᴇs*
┃𖠇 *.ᴊᴘᴍ*
┃𖠇 *.ᴊᴘᴍ1*
┃𖠇 *.ᴊᴘᴍ2*
┃𖠇 *.ᴊᴘᴍᴛᴇsᴛɪ*
┃𖠇 *.ᴊᴘᴍsʟɪᴅᴇ*
┃𖠇 *.ᴊᴘᴍsʟɪᴅᴇʜᴛ*
┃𖠇 *.ᴘᴜsʜᴋᴏɴᴛᴀᴋ*
┃𖠇 *.ᴘᴜsʜᴋᴏɴᴛᴀᴋ2*
┃𖠇 *.ᴘᴀʏᴍᴇɴᴛ*
┃𖠇 *.ᴘʀᴏᴅᴜᴋ*
┗────────────❖
┏─❖ *GROUP MENU* ❖
┃𖠇 *.ᴀᴅᴅ*
┃𖠇 *.ᴋɪᴄᴋ*
┃𖠇 *.ᴄʟᴏsᴇ*
┃𖠇 *.ᴏᴘᴇɴ*
┃𖠇 *.ʜɪᴅᴇᴛᴀɢ*
┃𖠇 *.ᴋᴜᴅᴇᴛᴀɢᴄ*
┃𖠇 *.ʟᴇᴀᴠᴇ*
┃𖠇 *.ʟᴇᴀᴠᴇ2*
┃𖠇 *.ᴛᴀɢᴀʟʟ*
┃𖠇 *.ᴘʀᴏᴍᴏᴛᴇ*
┃𖠇 *.ᴅᴇᴍᴏᴛᴇ*
┃𖠇 *.ʀᴇsᴇᴛʟɪɴᴋɢᴄ*
┃𖠇 *.ᴀɴᴛɪʟɪɴᴋ*
┃𖠇 *.ᴀɴᴛɪʟɪɴᴋ2*
┃𖠇 *.ᴡᴇʟᴄᴏᴍᴇ*
┃𖠇 *.ʟɪɴᴋɢᴄ*
┗────────────❖
┏─❖ *OWNER MENU* ❖
┃𖠇 *.ᴀᴅᴅᴏᴡɴᴇʀ*
┃𖠇 *.ʟɪsᴛᴏᴡɴᴇʀ*
┃𖠇 *.ᴅᴇʟᴏᴡɴᴇʀ*
┃𖠇 *.ᴀᴜᴛᴏʀᴇᴀᴅ*
┃𖠇 *.ᴀᴜᴛᴏᴘʀᴏᴍᴏsɪ*
┃𖠇 *.ᴀᴜᴛᴏʀᴇᴀᴅsᴡ*
┃𖠇 *.ᴀᴜᴛᴏᴛʏᴘɪɴɢ*
┃𖠇 *.sᴇʟғ*
┃𖠇 *.ᴘᴜʙʟɪᴄ*
┃𖠇 *.sᴇᴛɪᴍɢᴍᴇɴᴜ*
┃𖠇 *.sᴇᴛᴘᴘʙᴏᴛ*
┃𖠇 *.ᴄʟᴇᴀʀsᴇssɪᴏɴ*
┃𖠇 *.ᴄʟᴇᴀʀᴄʜᴀᴛ*
┃𖠇 *.ɢᴇᴛsᴄ*
┃𖠇 *.ɢᴇᴛᴄᴀsᴇ*
┃𖠇 *.ᴊᴏɪɴɢᴄ*
┃𖠇 *.ᴊᴏɪɴᴄʜ*
┃𖠇 *.ᴜᴘᴄʜᴀɴɴᴇʟ*
┃𖠇 *.ᴜᴘᴄʜᴀɴɴᴇʟ2*
┗────────────❖
┏─❖ *OWNER MENU* ❖
┃𖠇 *.1ɢʙ*
┃𖠇 *.2ɢʙ*
┃𖠇 *.3ɢʙ*
┃𖠇 *.4ɢʙ*
┃𖠇 *.5ɢʙ*
┃𖠇 *.6ɢʙ*
┃𖠇 *.7ɢʙ*
┃𖠇 *.8ɢʙ*
┃𖠇 *.9ɢʙ*
┃𖠇 *.10ɢʙ*
┃𖠇 *.ᴜɴʟɪᴍɪᴛᴇᴅ*
┃𖠇 *.ᴄᴀᴅᴍɪɴ*
┃𖠇 *.ᴅᴇʟᴘᴀɴᴇʟ*
┃𖠇 *.ᴅᴇʟᴀᴅᴍɪɴ*
┃𖠇 *.ʟɪsᴛᴘᴀɴᴇʟ*
┃𖠇 *.ʟɪsᴛᴀᴅᴍɪɴ*
┗────────────❖
`
 Kyami.sendMessage(m.chat, {document: fs.readFileSync("./package.json"), mimetype: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", caption: `${teksnya}`, fileName: `${botname2} V${global.versi}`, contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${global.botname}`, newsletterJid: global.idSaluran }, 
mentionedJid: [global.owner+"@s.whatsapp.net", m.sender], externalAdReply: {containsAutoReply: true, thumbnail: await fs.readFileSync("./src/media/menu.jpg"), title: `Raiden Shogun`, 
renderLargerThumbnail: true, sourceUrl: global.linkSaluran, mediaType: 1}}}, {quoted: qtroli})
}
break

//================================================================================

case "yts": {
if (!text) return reply("we dont talk")
await Kyami.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const anuan = ytsSearch.all
let teks = "\n *[ Result From Youtube Search 🔍 ]*\n\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${res.views}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n\n`
}
await reply(teks)
await Kyami.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
//================================================================================

case "shortlink": case "shorturl": {
if (!text) return reply("https://xnxx.com")
if (!isUrl(text)) return reply("https://example.com")
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl*
${res.data.toString()}
`
await Kyami.sendMessage(m.chat, {text: link}, {quoted: m})
}
break


case "shortlink-dl": {
if (!text) return reply("https://example.com")
if (!isUrl(text)) return reply("https://example.com")
var a = await fetch(`https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=${text}`)
await Kyami.sendMessage(m.chat, {text: a.url}, {quoted: m})
}

//================================================================================
case "play":{
if (!text) return reply(`\n*ex:* ${prefix + command} impossible\n`)
let mbut = await fetchJson(`https://ochinpo-helper.hf.space/yt?query=${text}`)
let ahh = mbut.result
let crot = ahh.download.audio

Kyami.sendMessage(m.chat, {
laudio: { url: crot },
mimetype: "audio/mpeg", 
ptt: true
}, { quoted: qkontak })
}
break
case "rvo": {
if (!m.quoted) return reply(
`*❌Syntax Error!!*
*Example:* Reply ViewOnce with caption ${prefix + command}`);
try {
let buffer = await m.quoted.download();
let type = m.quoted.mtype;
let sendOptions = { quoted: m };
if (type === "videoMessage") {
await Kyami.sendMessage(m.chat, { video: buffer, caption: m.quoted.text || "" }, sendOptions);
} else if (type === "imageMessage") {
await Kyami.sendMessage(m.chat, { image: buffer, caption: m.quoted.text || "" }, sendOptions);
} else if (type === "audioMessage") {
await kyami.sendMessage(m.chat, { 
audio: buffer, 
mimetype: "audio/mpeg", 
ptt: m.quoted.ptt || false 
}, sendOptions);
} else {
return reply("❌ Media View Once tidak didukung.");
}} catch (err) {
console.error(err)}}
break;

case 'idch': case 'cekidch': {

if (!text) return reply("linkchnya mana")
if (!text.includes("https://whatsapp.com/channel/")) return reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await Kyami.newsletterMetadata("invite", result)
let teks = `* *ID : ${res.id}*
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: { "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 },
interactiveMessage: {
body: {
text: teks }, 
footer: {
text: "powered by Kyami Silence | Raiden Shogun " }, //input watermark footer
  nativeFlowMessage: {
  buttons: [
             {
        "name": "cta_copy",
        "buttonParamsJson": `{"display_text": "copy ID","copy_code": "${res.id}"}`
           },
     ], },},
    }, }, },{ quoted : m });
await Kyami.relayMessage( msg.key.remoteJid,msg.message,{ messageId: msg.key.id }
);
}
break

//================================================================================
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
case "brat": {
if (!text) return reply("teksnya")
let brat = `https://api.nekorinn.my.id/maker/brat-v2?text=${encodeURIComponent(text)}&isVideo=false`
let response = await axios.get(brat, { responseType: "arraybuffer" })
let videoBuffer = response.data;
try {
await Kyami.sendAsSticker(m.chat, videoBuffer, m, {packname: global.packname})
} catch {}
}
break

case "listpanel": case "listp": case "listserver": {
if (!isCreator && !isPremium) return reply(mess.owner)
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f2 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f2.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await Kyami.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deladmin": {
if (!isCreator) return reply(mess.owner)
if (!text) {
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return Kyami.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return reply("Akun admin panel tidak ditemukan!")
await reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delpanel": {
if (!isCreator && !isPremium) return reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f2 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f2.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel ${s.id}`
})
}

return Kyami.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return reply("Server panel tidak ditemukan!")
reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break
case "cadmin": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply("username")
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`
await fs.writeFileSync("./akunpanel.txt", teks)
await Kyami.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: m})
await fs.unlinkSync("./akunpanel.txt")
}
break
case "pin": case "pinterest": {
if (!text) return reply("anime dark")
await Kyami.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pin = await pinterest2(text)
if (pin.length > 10) await pin.splice(0, 11)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.images_url}`}}, { upload: Kyami.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.images_url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `🔎 Result From Pinterest`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await Kyami.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
await Kyami.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//================================================================================

case "ai": case "gpt": case "openai": {
if (!text) return reply("apa itu nodejs")
await fetchJson("https://diibot-api.vercel.app/api/ai/gpt-prompt?query="+text).then(async (res) => {
await reply(res.result.toString())
}).catch(e => reply(e.toString()))
}
break

//================================================================================

case "qc": {
if (!text) return reply("teksnya")
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
var ppuser
try {
ppuser = await Kyami.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#000000",
"width": 812,
"height": 968,
"scale": 2,
"messages": [
 {
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": m.pushName,
"photo": {
 "url": ppuser
}
},
"text": text,
"replyMessage": {}
 }
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
 const buffer = Buffer.from(res.data.result.image, 'base64')
 let tempnya = "./database/sampah/"+m.sender+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return reply("Error")
await Kyami.sendAsSticker(m.chat, tempnya, m, {packname: global.packname})
await fs.unlinkSync(`${tempnya}`)
})
})
}
break

//================================================================================

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return reply("dengan kirim media")
if (/video/gi.test(mime) && qmsg.seconds > 15) return reply("Durasi vidio maksimal 15 detik!")
var image = await Kyami.downloadAndSaveMediaMessage(qmsg)
await Kyami.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

//================================================================================

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return reply("namamu dengan kirim media")
if (!/image|video/gi.test(mime)) return reply("namamu dengan kirim media")
if (/video/gi.test(mime) && qmsg.seconds > 15) return reply("Durasi vidio maksimal 15 detik!")
var image = await Kyami.downloadAndSaveMediaMessage(qmsg)
await Kyami.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

//================================================================================

case "tourl": {
if (!/image/.test(mime)) return reply("dengan kirim/reply foto")
let media = await Kyami.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'scriptfree.png');

await Kyami.sendMessage(m.chat, {text: `${directLink}`}, {quoted: m})
await fs.unlinkSync(media)
}
break

//================================================================================

case "tourl2": {
if (!/image/.test(mime)) return reply("dengan kirim/reply foto")
let foto = await Kyami.downloadAndSaveMediaMessage(qmsg)
let result = await TelegraPh(await fs.readFileSync(foto))
await Kyami.sendMessage(m.chat, {text: `${result}`}, {quoted: m})
await fs.unlinkSync(foto)
}
break

//================================================================================

case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return reply("id good night")
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return reply("id good night")
if (args.length < 1) return reply("id good night")
if (!m.quoted.text) return reply("id good night")
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
reply(result[0])
}
} else {
return reply("id good night")
}}
break

//================================================================================

case "tohd": case "hd": {
if (!/image/.test(mime)) return reply("dengan kirim/reply foto")
let foto = await Kyami.downloadAndSaveMediaMessage(qmsg)
let result = await remini(await fs.readFileSync(foto), "enhance")
await Kyami.sendMessage(m.chat, {image: result}, {quoted: m})
await fs.unlinkSync(foto)
}
break

//================================================================================

case "add": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await Kyami.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return reply("Nomor Tidak Terdaftar Di WhatsApp")
const res = await Kyami.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return reply(JSON.stringify(res, null, 2))
}} else {
return reply("62838###")
}
}
break

//================================================================================

case "kick": case "kik": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await Kyami.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return reply("Nomor Tidak Terdaftar Di WhatsApp")
const res = await Kyami.groupParticipantsUpdate(m.chat, [input], 'remove')
await reply(`Berhasil Mengeluarkan ${input.split("@")[0]} Dari Grup Ini`)
} else {
return reply("@tag/reply")
}
}
break

//================================================================================

case "leave": {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
await reply("Baik, Saya Akan Keluar Dari Grup Ini")
await sleep(4000)
await Kyami.groupLeave(m.chat)
}
break

//================================================================================

case "resetlinkgc": {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return reply(mess.botAdmin)
await Kyami.groupRevokeInvite(m.chat)
reply("Sukses Reset Link Grup ✅")
}
break

//================================================================================

//================================================================================

case "tagall": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!text) return reply("pesannya")
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await Kyami.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break

//================================================================================

case "linkgc": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await Kyami.groupInviteCode(m.chat)
var teks = `
${urlGrup}

- ${m.metadata.subject}
`
await Kyami.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

//================================================================================

case "ht": case "hidetag": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (!text) return reply("pesannya")
let member = m.metadata.participants.map(v => v.id)
await Kyami.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

//================================================================================

case "joingc": case "join": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply("linkgcnya")
if (!text.includes("https://whatsapp.com/channel/")) return reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
await Kyami.groupAcceptInvite(result)
reply("Sukses Join Grup")
}
break
//================================================================================
case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isCreator && !isPremium) return reply(mess.owner)
if (!text) return reply("username")
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "2000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "3000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "4000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "5000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "6000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "7000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "8000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "9000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "10000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `*Data Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}*
* Disk : *${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu+"%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`
await fs.writeFileSync("akunpanel.txt", teks)
await Kyami.sendMessage(orang, {document: fs.readFileSync("./akunpanel.txt"), fileName: "akunpanel.txt", mimetype: "text/plain", caption: teks}, {quoted: m})
await fs.unlinkSync("./akunpanel.txt")
delete global.panel
}
break

case "joinch": case "joinchannel": {
if (!isCreator) return reply(mess.owner)
if (!text && !m.quoted) return reply("linkchnya")
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return reply("Link Tautan Tidak Valid!")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await Kyami.newsletterMetadata("invite", result)
await Kyami.newsletterFollow(res.id)
reply(`*Berhasil Join Saluran ✅*
* Nama Channel : *${res.name}*
* Total Pengikut : *${res.subscribers + 1}*`)
}
break
case "welcome": {
 if (!isCreator) return reply(mess.owner);
 if (!m.isGroup) return reply(mess.group);

 if (!q) {
return reply("Silakan masukkan teks `on` atau `off` setelah perintah .welcome untuk mengaktifkan atau menonaktifkan Welcome Message.");
 }
 if (!db.groups[m.chat]) {
db.groups[m.chat] = {};
 }
 if (db.groups[m.chat].welcome === undefined) {
db.groups[m.chat].welcome = false;
 }

 if (q.toLowerCase() == "on") {
if (db.groups[m.chat].welcome === true) {
return reply("Welcome Message sudah aktif di grup ini!");
}
db.groups[m.chat].welcome = true;
await reply("Berhasil mengaktifkan Welcome Message di grup ini.");
 } else if (q.toLowerCase() == "off") {
if (db.groups[m.chat].welcome === false) {
return reply("Welcome Message sudah nonaktif di grup ini!");
}
db.groups[m.chat].welcome = false;
await reply("Berhasil menonaktifkan Welcome Message di grup ini.");
 } else {
return reply("Input tidak valid. Silakan ketik `.welcome on` untuk mengaktifkan atau `.welcome off` untuk menonaktifkan Welcome Message.");
 }
}
break
//================================================================================
case "antilink": {
 if (!isCreator) return reply(mess.owner);
 if (!m.isGroup) return reply(mess.group);

 if (!q) {
return reply("Silakan masukkan teks `on` atau `off` setelah perintah .antilink untuk mengaktifkan atau menonaktifkan antilink.");
 }
 if (!global.db.groups[m.chat]) {
global.db.groups[m.chat] = {};
 }

 if (q.toLowerCase() == "on") {
if (global.db.groups[m.chat].antilink === true) {
return reply("Antilink Group sudah aktif di grup ini!");
}
if (global.db.groups[m.chat].antilink2 === true) {
global.db.groups[m.chat].antilink2 = false;
}
global.db.groups[m.chat].antilink = true;
await reply("Berhasil menyalakan Antilink Group di grup ini.");
 } else if (q.toLowerCase() == "off") {
if (global.db.groups[m.chat].antilink === false) {
return reply("Antilink Group tidak aktif di grup ini!");
}
global.db.groups[m.chat].antilink = false;
await reply("Berhasil mematikan Antilink Group di grup ini.");
 } else {
return reply("Perintah tidak valid. Silakan masukkan `on` atau `off` setelah perintah .antilink.");
 }
}
break;
//================================================================================
case "mute": {
 if (!isCreator) return reply(mess.owner);
 if (!m.isGroup) return reply(mess.group);

 if (!q) {
return reply("Silakan masukkan teks `on` atau `off` setelah perintah .mute untuk mengaktifkan atau menonaktifkan mute.");
 }
 if (!global.db.groups[m.chat]) {
global.db.groups[m.chat] = {};
 }
 if (global.db.groups[m.chat].mute === undefined) {
global.db.groups[m.chat].mute = false;
 }

 if (q.toLowerCase() == "on") {
if (global.db.groups[m.chat].mute === true) {
return reply("Grup Ini Sudah Dalam Keadaan Mute!");
}
global.db.groups[m.chat].mute = true;
await reply("Berhasil Mute Grup Ini");
 } else if (q.toLowerCase() == "off") {
if (global.db.groups[m.chat].mute === false) {
return reply("Grup Ini Tidak Dalam Keadaan Mute!");
}
global.db.groups[m.chat].mute = false;
await reply("Berhasil Unmute Grup Ini");
 } else {
return reply("Perintah tidak valid. Silakan masukkan `on` atau `off` setelah perintah .mute.");
 }
}
break;

//================================================================================
case "antilink2": {
 if (!isCreator) return reply(mess.owner);
 if (!m.isGroup) return reply(mess.group);

 if (!q) {
return reply("Silakan masukkan teks `on` atau `off` setelah perintah .antilink2 untuk mengaktifkan atau menonaktifkan antilink2.");
 }
 if (!global.db.groups[m.chat]) {
global.db.groups[m.chat] = {};
 }
 if (global.db.groups[m.chat].antilink2 === undefined) {
global.db.groups[m.chat].antilink2 = false;
 }

 if (q.toLowerCase() == "on") {
if (global.db.groups[m.chat].antilink2 === true) {
return reply("Antilink2 Group Sudah Aktif Di Grup Ini!");
}
if (global.db.groups[m.chat].antilink === true) {
global.db.groups[m.chat].antilink = false;
}

global.db.groups[m.chat].antilink2 = true;
await reply("Berhasil Menyalakan Antilink2 Group Di Grup Ini");

 } else if (q.toLowerCase() == "off") {
if (global.db.groups[m.chat].antilink2 === false) {
return reply("Antilink2 Group Tidak Aktif Di Grup Ini!");
}

global.db.groups[m.chat].antilink2 = false;
await reply("Berhasil Mematikan Antilink2 Group Di Grup Ini");

 } else {
return reply("Perintah tidak valid. Silakan masukkan `on` atau `off` setelah perintah .antilink2.");
 }
}
break;
//================================================================================

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return reply("Status Grup Sudah Terbuka!")
await Kyami.groupSettingUpdate(m.chat, 'not_announcement')
return reply(`Berhasil Membuka Grup`)
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return reply("Status Grup Sudah Tertutup!")
await Kyami.groupSettingUpdate(m.chat, 'announcement')
return reply(`Berhasil Menutup Grup`)
} else {}
}
break;

//================================================================================
case "kudetagc": case "kudeta": {
 if (!isCreator) return reply(mess.owner);
 if (!m.isGroup) return reply(mess.group);
 if (!global.db.groups[m.chat]) {
global.db.groups[m.chat] = {};
 }
 let memberFilter = await m.metadata.participants
.map(v => v.id)
.filter(e => e !== botNumber && e !== m.sender);
 if (memberFilter.length < 1) return reply("Grup ini sudah tidak ada member!");
 await reply("Kudeta Grup By Kyami Starting 🔥");
 for (let i of memberFilter) {
try {
await Kyami.groupParticipantsUpdate(m.chat, [i], 'remove');
await sleep(2000);
} catch (error) {
console.error(`Failed to remove member ${i}: ${error.message}`);
await reply(`Gagal mengeluarkan member dengan ID ${i}`);
}
 }

 await reply("Kudeta Grup Telah Berhasil 🏴‍☠️");
}
break;
//================================================================================

case "demote":
case "promote": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await Kyami.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await Kyami.sendMessage(m.chat, {text: `Sukses ${action} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return reply("@tag/6285###")
}
}
break
case "produk": {
await slideButton(m.chat)
}
break

//================================================================================

break

//================================================================================

case "pushkontak": {
if (!isOwner) return reply(mess.owner)
if (!text) return reply("idgrup|pesannya")

const parts = text.split("|")
if (parts.length !== 2) return reply("idgrup|pesannya")

const [idgc, pes] = parts
const teks = pes
const jidawal = m.chat

try {
const data = await Kyami.groupMetadata(idgc)
const halls = await data.participants
.filter(v => 
v.id.endsWith('.net') && 
v.id !== botNumber && 
v.id.split("@")[0] !== global.owner
)
.map(v => v.id)

 await reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

 for (let mem of halls) {
const vcard = 'BEGIN:VCARD\n'
+ 'VERSION:3.0\n' 
+ `FN:${namaOwner}\n`
+ 'ORG:Developer;\n'
+ `TEL;type=CELL;type=VOICE;waid=${global.owner}:${global.owner}\n`
+ 'END:VCARD'

const sentMsg = await Kyami.sendMessage(mem, { 
contacts: { 
 displayName: namaOwner, 
 contacts: [{ vcard }] 
}
})

await Kyami.sendMessage(mem, { text: teks }, { quoted: sentMsg })
await sleep(global.delayPushkontak)
 }

 await Kyami.sendMessage(jidawal, {
text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`
 }, { quoted: m })

} catch (error) {
 console.error("Error in pushkontak:", error)
 await reply("Terjadi kesalahan saat memproses pushkontak")
}
}
break

//================================================================================

case "pushkontak2": {
if (!isOwner) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!text) return reply("pesannya")
const teks = text
const jidawal = m.chat
const data = await Kyami.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await reply(`Memproses *pushkontak*`)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
const vcard = 'BEGIN:VCARD\n'
+ 'VERSION:3.0\n' 
+ `FN:${namaOwner}\n`
+ 'ORG:Developer;\n'
+ `TEL;type=CELL;type=VOICE;waid=${global.owner}:${global.owner}\n`
+ 'END:VCARD'
const sentMsg= await Kyami.sendMessage(mem, { contacts: { displayName: namaOwner, contacts: [{ vcard }] }})
await Kyami.sendMessage(mem, {text: teks}, {quoted: sentMsg })
await sleep(global.delayPushkontak)
}}

await Kyami.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break
//================================================================================

case "jpmslide": {
if (!isCreator) return reply(mess.owner)
let allgrup = await Kyami.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await reply(`Memproses Pengiriman Pesan Ke ${res.length} Grup Chat`)
for (let i of res) {
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Kyami.sendMessage(jid, {text: `Pesan Berhasil Dikirim ✅\nTotal Pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return reply(mess.owner)
let allgrup = await Kyami.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await reply(`Memproses Pengiriman Pesan Ke ${res.length} Grup Chat`)
for (let i of res) {
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Kyami.sendMessage(jid, {text: `Pesan Berhasil Dikirim ✅\nTotal Pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpm": {
if (!isCreator) return reply(mess.owner)
if (!q) return reply("teksnya")

const bannedGroups = global.bannedGroups;
let allgrup = await Kyami.groupFetchAllParticipating();
let res = Object.keys(allgrup);
let count = 0;
const jid = m.chat;
const teks = q;
await reply(`Memproses Pengiriman Pesan Ke ${res.length} Grup Chat`);

for (let i of res) {
if (bannedGroups.includes(i)) {
console.log(`Grup ${i} diblokir, melewati...`);
continue;
}
try {
await Kyami.sendMessage(i, { text: `${teks}` }, { quoted: qtext });
count += 1;
} catch (err) {
console.error(`Gagal mengirim ke grup ${i}:`, err);
}
await sleep(global.delayJpm);
}

await Kyami.sendMessage(jid, { 
text: `Pesan Berhasil Dikirim ✅\nTotal Pesan : ${count}` 
}, { quoted: qlocJpm });
}
break;


//================================================================================

case "jpm": {
if (!isCreator) return reply(mess.owner)
if (!q) return reply("teksnya")
let allgrup = await Kyami.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await reply(`Memproses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await Kyami.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Kyami.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpm2": {
if (!isCreator) return reply(mess.owner)
if (!q) return reply("teks dengan mengirim foto")
if (!/image/.test(mime)) return reply("teks dengan mengirim foto")
const allgrup = await Kyami.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await Kyami.downloadAndSaveMediaMessage(qmsg)
await reply(`Memproses *jpm* teks & foto Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await Kyami.sendMessage(i, {image: fs.readFileSync(rest), caption: teks}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await Kyami.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================
case "jpmtesti": {
if (!isCreator) return reply(mess.owner); // Hanya owner yang bisa
if (!q) return reply("Teks dengan mengirim foto"); // Validasi input teks
if (!/image/.test(mime)) return reply("Teks dengan mengirim foto"); // Validasi mime tipe

const bannedGroups = global.bannedGroups || []; // List grup yang diblokir
const allgrup = await Kyami.groupFetchAllParticipating(); // Ambil semua grup
const res = Object.keys(allgrup); // ID grup
let count = 0; // Jumlah grup sukses
let failCount = 0; // Jumlah grup gagal
const teks = q; // Simpan teks tetap
const jid = m.chat;
const rest = await Kyami.downloadAndSaveMediaMessage(qmsg); // Download media

await reply(`Memproses Pengiriman Pesan ke ${res.length} Grup Chat...`);

for (let i of res) {
 const group = allgrup[i];
 console.log(`Memeriksa grup: ${i}`, group);

 // Abaikan grup jika ada di daftar banned
 if (bannedGroups.includes(i)) {
console.log(`Grup ${i} diblokir, melewati.`);
failCount += 1;
continue;
 }

 // Tetap coba kirim walaupun bot bukan admin atau data grup tidak lengkap
 try {
const botParticipant = group.participants?.find(
(p) => p.id === `${global.botNumber}@s.whatsapp.net`
);

if (!group.participants || !botParticipant) {
console.log(`Grup ${i} data tidak lengkap, tetap mencoba kirim.`);
} else if (group.restrict || botParticipant.admin !== "admin") {
console.log(`Bot bukan admin di grup ${i}, tetap mencoba kirim.`);
}

// Kirim pesan ke grup
await Kyami.sendMessage(
i,
{
 image: await fs.readFileSync(rest),
 caption: teks,
 contextInfo: {
isForwarded: true,
mentionedJid: [m.sender],
businessMessageForwardInfo: {
businessOwnerJid: `${global.ownerUtama}@s.whatsapp.net`,
},
forwardedNewsletterMessageInfo: {
newsletterName: global.namaSaluran,
newsletterJid: global.idSaluran,
},
 },
},
{ quoted: qtoko }
);
count += 1;
console.log(`Pesan berhasil dikirim ke grup ${i}.`);
 } catch (err) {
console.error(`Gagal mengirim ke grup ${i}:`, err);
failCount += 1;
 }

 await sleep(global.delayJpm); // Delay sesuai konfigurasi
}

// Hapus file sementara
try {
 await fs.unlinkSync(rest);
} catch (err) {
 console.error("Gagal menghapus file sementara:", err);
}

// Kirim laporan hasil pengiriman
await Kyami.sendMessage(
 jid,
 {
text: `Pengiriman selesai ✅\n- Sukses: ${count}\n- Gagal: ${failCount}\nTotal Grup: ${res.length}`,
 },
 { quoted: m }
);
}
//================================================================================

case "pay": case "payment": {
if (!isCreator) return reply(mess.owner)
let imgdana = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/dana.jpg")}, { upload: Kyami.waUploadToServer })
let imgovo = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/ovo.jpg")}, { upload: Kyami.waUploadToServer })
let imggopay = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/gopay.jpg")}, { upload: Kyami.waUploadToServer })
let imgqris = await prepareWAMessageMedia({ image: fs.readFileSync("./src/media/qris.jpg")}, { upload: Kyami.waUploadToServer })
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "Pilih Payment Pembayaran"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgdana
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Dana Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.dana}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgovo
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"OVO Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.ovo}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imggopay
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Gopay Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.gopay}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgqris
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\" QRIS Payment\",\"url\":\"${global.qris}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}
]
})
})}
}}, {userJid: m.sender, quoted: qtoko})
await Kyami.relayMessage(m.chat, msgii.message, {messageId: msgii.key.id})
}
break

//================================================================================

case "dana": {
if (!isCreator) return
let teks = `
*PAYMENT DANA KYAMI - SILENCE*

* *Nomor :* 081250431837
* *Atas Nama :* RU****

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await Kyami.sendMessage(m.chat, {text: teks}, {quoted: qtoko})
}
break
case "qris": {
if (!isCreator) return 
await Kyami.sendMessage(m.chat, {image: {url: "https://img100.pixhost.to/images/155/533947790_Kyami Silence.jpg"}, caption: "\n*PAYMENT QRIS KYAMI - SILENCE📚*\n\n*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`"}, {quoted: qtoko})
}
break

//================================================================================

case "ambilq": case "q": {
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
reply(jsonData)
} 
break

//================================================================================
case "done": {
 if (!isCreator) return reply("Khusus Owner");
 if (!text) return reply("barang,harga,payment\n\n*Contoh :* Panel Unlimited,2,OVO");
 
 const parts = text.split(",");
 if (parts.length < 3) return reply("barang,harga,payment\n\n*Contoh :* Panel Unlimited,2,OVO");
 
 const [barang, harga, payment] = parts;
 if (isNaN(harga)) return reply("Format Harga Tidak Valid");
 
 const total = `${harga}000000`;
 const total2 = Number(`${harga}000`);
 const teks = `TRANSAKSI BERHASIL✅
📦BARANG: ${barang}
💸NOMINAL: Rp${Number(total2)}
🧧PAYMENT: ${payment}
🗓️TANGGAL: ${tanggal(Date.now())}

📞WA REAL:6285640493829(LIM)

LINK GRUP TERBUKA:
JANGAN LUPA MASUK
https://chat.whatsapp.com/LM7UPv6vivR25eQei5R6O8`;

 Kyami.relayMessage(m.chat, {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: Number(total),
requestFrom: m.sender,
noteMessage: {
 extendedTextMessage: {
text: teks,
contextInfo: {
externalAdReply: {
 showAdAttribution: true
}
}
 }
}
}
 }, {});
}
break

//================================================================================

case "proses": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply("`[ Contoh ]` *.proses* Teks")
const teks12 = `
*Transkasi Proses ⏰*
*📦 ${text}*

*_2024 - KYAMI - SILENCE_*
`
reply(teks12)
}
break
//================================================================================

case "developerbot": case "owner": {
await Kyami.sendContact(m.chat, [global.ownerUtama], qtext)
}
break

//================================================================================

case "self": {
if (!isCreator) return
Kyami.public = false
reply("Berhasil Beralih Ke Mode Self")
}
break

//================================================================================

case "getcase": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply("menu")
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./case.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
reply(`${getcase(q)}`)
} catch (e) {
return reply(`Case *${text}* Tidak Ditemukan`)
}
}
break

//================================================================================

case "ping": {
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
let respon = `
*Informasi Server*
• OS: ${tio}
• IP Address: ${nou.os.ip()}
• Type OS: ${nou.os.type()}

*Ram Server*
• Total: ${formatp(os.totalmem())}
• Digunakan: ${formatp(os.totalmem() - os.freemem())}

*Penyimpanan*
• Total: ${tot.totalGb} GB
• Digunakan: ${tot.usedGb} GB > ${tot.usedPercentage}%
• Tersedia: ${tot.freeGb} GB > ${tot.freePercentage}%

• Respon: ${latensi.toFixed(4)} detik
`
await reply(respon)
}
break

//================================================================================

case "public": {
if (!isCreator) return
Kyami.public = true
reply("Berhasil Beralih Ke Mode Public")
}
break

//================================================================================

case "scbot": case "sc": {
var teks = `
 *# Script Bot Raiden Shogun*
 
 *🌐 Donwload Script :* 
 YouTube : @SlncKyami
`
await Kyami.relayMessage(m.chat,{requestPaymentMessage: {currencyCodeIso4217: 'IRP', amount1000: 99999000, requestFrom: m.sender, noteMessage: { extendedTextMessage: { text: teks, contextInfo: {
quotedMessage: m.message
}}}}}, {userJid: m.sender, quoted: m})
}
break

//================================================================================

case "restart": case "rst": {
if (!isCreator) return reply(mess.owner)
await reply("Restarting bot . . .")
var file = await fs.readdirSync("./session")
var anu = await file.filter(i => i !== "creds.json")
for (let t of anu) {
await fs.unlinkSync(`./session/${t}`)
}
await process.send('reset')
}
break

//================================================================================

case "clearsession": case "clsesi": {
if (!isCreator) return reply(mess.owner)
var file = await fs.readdirSync("./session")
var anu = file.filter(i => i !== "creds.json")
for (let t of anu) {
await fs.unlinkSync(`./session/${t}`)
}
await reply("Sukses Clear Session ✅")
}
break

//================================================================================

case "autopromosi": {
if (!isCreator) return reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}

Untuk mengubah status, gunakan perintah:
- .autopromosi on
- .autopromosi off`
await reply(teksnya)
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.autopromosi == true) return reply("Autopromosi Sudah Aktif!")
global.db.settings.autopromosi = true
await reply("Berhasil Menyalakan Autopromosi")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.autopromosi == false) return reply("Autopromosi Sudah Tidak Aktif!")
global.db.settings.autopromosi = false
await reply("Berhasil Mematikan Autopromosi")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

//================================================================================

case "autoread": {
if (!isCreator) return reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}

Untuk mengubah status, gunakan perintah:
- .autoread on
- .autoread off`
await reply(teksnya)
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.autoread == true) return reply("Autoread Message Sudah Aktif!")
global.db.settings.autoread = true
await reply("Berhasil Menyalakan Autoread Message")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.autoread == false) return reply("Autoread Message Sudah Tidak Aktif!")
global.db.settings.autoread = false
await reply("Berhasil Mematikan Autoread Message")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

//================================================================================

case "autotyping": {
if (!isCreator) return reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}

Untuk mengubah status, gunakan perintah:
- .autotyping on
- .autotyping off`
await reply(teksnya)
}
if (!q) return sendStatusGc() 
if (q.toLowerCase() == "on") {
if (global.db.settings.autotyping == true) return reply("Auto Typing Sudah Aktif!")
global.db.settings.autotyping = true
await reply("Berhasil Menyalakan Auto Typing")
sendStatusGc() 
} else if (q.toLowerCase() == "off") {
if (global.db.settings.autotyping == false) return reply("Auto Typing Sudah Tidak Aktif!")
global.db.settings.autotyping = false
await reply("Berhasil Mematikan Auto Typing")
sendStatusGc() 
} else {
return sendStatusGc() 
}}
break

//================================================================================

case "autoreadsw": {
if (!isCreator) return reply(mess.owner)
async function sendStatusGc() {
let teksnya = `
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}

Untuk mengubah status, gunakan perintah:
- .autoreadsw on
- .autoreadsw off`
await reply(teksnya)
}
if (!q) return sendStatusGc()
if (q.toLowerCase() == "on") {
if (global.db.settings.readsw == true) return reply("Autoread Story Sudah Aktif!")
global.db.settings.readsw = true
await reply("Berhasil Menyalakan Autoread Story")
await sendStatusGc()
} else if (q.toLowerCase() == "off") {
if (global.db.settings.readsw == false) return reply("Autoread Story Sudah Tidak Aktif!")
global.db.settings.readsw = false
await reply("Berhasil Mematikan Autoread Story")
await sendStatusGc()
} else {
return sendStatusGc()
}}
break

//================================================================================

case "upchannel": case "upch": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply("teksnya")
await Kyami.sendMessage(idSaluran, {text: text})
reply("Berhasil Mengirim Pesan Teks Ke Channel Whatsapp")
}
break

//================================================================================

case "upchannel2": case "upch2": {
if (!isCreator) return reply(mess.owner)
if (!text) return reply("teksnya dengan mengirim foto")
if (!/image/.test(mime)) return reply("teksnya dengan mengirim foto")
let img = await Kyami.downloadAndSaveMediaMessage(qmsg)
await Kyami.sendMessage(idSaluran, {image: await fs.readFileSync(img), caption: text})
reply("Berhasil Mengirim Pesan Teks & Foto Ke Channel Whatsapp")
await fs.unlinkSync(img)
}
break

//================================================================================

/*case "getsc": {
if (!isCreator) return reply(mess.owner)
let dir = await fs.readdirSync("./database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./database/sampah/${i}`)
}}
await reply("Memproses Backup Script Bot")
var name = `Raiden Shogun`
const ls = (await execSync("ls")
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await Kyami.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return reply("Script Berhasil Dikirim Ke Private Chat")
}
break*/

//================================================================================

case "setppbot": {
if (!isCreator) return reply(mess.owner)
if (/image/g.test(mime)) {
var medis = await Kyami.downloadAndSaveMediaMessage(qmsg)
if (args[0] && args[0] == "panjang") {
const { img } = await generateProfilePicture(medis)
await Kyami.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
await fs.unlinkSync(medis)
reply("*Berhasil Mengganti Profil Panjang ✅*")
} else {
await Kyami.updateProfilePicture(botNumber, {content: medis})
await fs.unlinkSync(medis)
reply("*Berhasil Mengganti Profil ✅*")
}
} else return reply("dengan mengirim foto")
}
break

//================================================================================

case "setimgmenu": {
if (!isCreator) return reply(mess.owner)
if (!/image/.test(mime)) return reply("Kirim Foto Dengan Caption *.setimgmenu*")
await Kyami.downloadAndSaveMediaMessage(qmsg, "./src/media/menu.jpg", false)
await reply("Berhasil Mengganti Thumbnail Menu ✅")
}
break

//================================================================================

case "clearchat": case "clc": {
if (!isCreator) return reply(mess.owner)
Kyami.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

//================================================================================

case "listowner": case "listown": {
if (owners.length < 1) return reply("Tidak ada owner tambahan")
let teks = `\n`
for (let i of owners) {
teks += `* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
Kyami.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

//================================================================================

case "delowner": case "delown": {
if (!isCreator) return reply(mess.owner)
if (!m.quoted && !text) return reply("6285###")
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (global.owner.includes(input2) || input2 === global.ownerUtama || input == botNumber) return reply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return reply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owners, null, 2))
reply(`Sukses menghapus ${input2} sebagai owner bot ✅`)
}
break

//================================================================================

case "addowner": case "addown": {
if (!isCreator) return reply(mess.owner)
if (!m.quoted && !text) return reply("6285###")
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (global.owner.includes(input2) || input2 === global.ownerUtama || owners.includes(input) || input === botNumber) return reply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owners, null, 2))
reply(`Sukses menjadikan ${input2} sebagai owner bot ✅`)
}
break
case "settingmenu": {
const teks = `
*🚦Setting Group WhatsApp*
* *Antilink :* ${db.groups[m.chat].antilink ? "✅" : "❌"}
* *Antilink V2 :* ${db.groups[m.chat].antilink2 ? "✅" : "❌"}
* *Welcome :* ${db.groups[m.chat].welcome ? "✅" : "❌"}
* *Mute :* ${db.groups[m.chat].mute ? "✅" : "❌"}

*🚦Setting Bot WhatsApp*
* *Autoread :* ${db.settings.autoread ? "✅" : "❌"}
* *Autoread Sw :* ${db.settings.readsw ? "✅" : "❌"}
* *Auto Typing :* ${db.settings.autotyping ? "✅" : "❌"}
* *Auto Promosi :* ${db.settings.autopromosi ? "✅" : "❌"}
`
reply(teks);
}
break
case "listgc": case "listgrup": {
let teks = `\n *#- List all group chat*\n`
let a = await Kyami.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return reply(teks)
}
break
//================================================================================

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))
}}

//================================================================================

if (m.text.toLowerCase() == "bot") {
reply("Bot Online ✅")
}

//================================================================================

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))
}}

//================================================================================

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return reply(`${err}`)
if (stdout) return reply(stdout)
})
}

//================================================================================

}} catch (err) {
console.log(util.format(err));
Kyami.sendMessage("6285640493829@s.whatsapp.net", {text: '*Fitur Error Terdeteksi*\n\n*Log error :*\n' + util.format(err), contextInfo: { isForwarded: true }}, {quoted: m})
}}

//================================================================================

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});